let lb = require("./lib");
console.log(lb.f(50));
