function previous(x) {
    return x - 1;
}
console.log(previous(50));