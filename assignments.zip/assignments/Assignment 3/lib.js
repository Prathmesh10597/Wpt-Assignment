exports.f = function (x) {
    return x - 1;
}